from flask import Flask, render_template, request, redirect, send_file, flash, jsonify, send_from_directory
from werkzeug.utils import secure_filename
import pandas as pd
import os
import time
import io
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from utils import check_email_reachability, validate_email_syntax, get_mx_record, verify_smtp_server, load_disposable_domains

app = Flask(__name__)
app.secret_key = 'your_secret_key'
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Load disposable domains once at startup
disposable_domains = load_disposable_domains()
# Initialize global progress tracker
progress = []
progress_lock = threading.Lock()

@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    if request.method == 'POST':
        email = request.form['email']
        sender_email = request.form.get('sender_email', 'test@example.com')

        if email:
            is_valid, message = check_email_reachability(email, sender_email, disposable_domains)
            result = {
                'email': email,
                'status': 'Valid' if is_valid else 'Invalid',
                'message': message
            }
        else:
            flash('Please enter an email address.', 'danger')

    return render_template('index.html', result=result)

@app.route('/batch', methods=['GET', 'POST'])
def batch():
    global progress
    results = []
    columns = []
    selected_column = None
    progress = []

    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)

        file = request.files['file']

        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)

        if file and file.filename.endswith('.csv'):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            df = pd.read_csv(filepath)
            columns = df.columns.tolist()

            selected_column = request.form.get('email_column')
            sender_email = request.form.get('sender_email', 'test@example.com')

            if selected_column and selected_column in df.columns:
                emails = df[selected_column].dropna().unique()
                total_emails = len(emails)

                email_result_map = {}

                def validate_email(i, email):
                    if not validate_email_syntax(email):
                        result = (email, "Invalid", "Invalid syntax")
                    else:
                        is_valid, message = check_email_reachability(email, sender_email, disposable_domains)
                        result = (email, "Valid" if is_valid else "Invalid", message)

                    with progress_lock:
                        progress.append({"processed": len(progress) + 1, "total": total_emails})
                    return result

                with ThreadPoolExecutor(max_workers=500) as executor:
                    futures = {executor.submit(validate_email, i, str(email)): email for i, email in enumerate(emails)}
                    for future in as_completed(futures):
                        email, status, message = future.result()
                        email_result_map[email] = {"Status": status, "Validation_Message": message}

                # Merge results back into original dataframe
                df['Status'] = df[selected_column].map(lambda x: email_result_map.get(str(x), {}).get('Status', 'Unknown'))
                df['Validation_Message'] = df[selected_column].map(lambda x: email_result_map.get(str(x), {}).get('Validation_Message', ''))

                # Create filtered DataFrames
                valid_df = df[df['Status'] == 'Valid']
                invalid_df = df[df['Status'] == 'Invalid']

                # Save files
                timestamp = time.strftime('%Y%m%d_%H%M%S')
                valid_path = os.path.join(app.config['UPLOAD_FOLDER'], f'valid_emails_{timestamp}.csv')
                invalid_path = os.path.join(app.config['UPLOAD_FOLDER'], f'invalid_emails_{timestamp}.csv')
                valid_df.to_csv(valid_path, index=False)
                invalid_df.to_csv(invalid_path, index=False)

                return render_template('downloads.html', valid_file=f'valid_emails_{timestamp}.csv', invalid_file=f'invalid_emails_{timestamp}.csv')
            else:
                flash("Selected column not found.", 'danger')

    return render_template('batch.html', columns=columns, selected_column=selected_column)

@app.route('/batch-progress')
def batch_progress():
    return jsonify(progress)

@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)